# -*- coding: utf-8 -*-

# FLO-2D Preprocessor tools for QGIS
# Copyright © 2021 Lutra Consulting for FLO-2D

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version

import csv
import io

from qgis.core import QgsMessageLog
from qgis.PyQt import QtCore
from qgis.PyQt.QtCore import QEvent, QObject, QSize, Qt, pyqtSignal
from qgis.PyQt.QtGui import QStandardItem, QStandardItemModel
from qgis.PyQt.QtWidgets import QApplication, QTableView, QUndoCommand, QUndoStack

from ..user_communication import UserCommunication
from ..utils import is_number
from .ui_utils import load_ui

uiDialog, qtBaseClass = load_ui("table_editor")


class TableEditorWidget(qtBaseClass, uiDialog):
    before_paste = pyqtSignal()
    after_paste = pyqtSignal()
    after_delete = pyqtSignal()

    def __init__(self, iface, plot, lyrs):
        qtBaseClass.__init__(self)
        uiDialog.__init__(self)
        self.iface = iface
        self.plot = plot
        self.lyrs = lyrs
        self.setupUi(self)
        self.setup_tview()
        self.tview.undoStack = QUndoStack(self)
        self.uc = UserCommunication(iface, "FLO-2D")
        self.gutils = None
        self.copy_btn.clicked.connect(self.copy_selection)
        self.paste_btn.clicked.connect(self.paste)
        self.undo_btn.clicked.connect(self.undo)
        self.redo_btn.clicked.connect(self.redo)
        self.connect_delete(True)
        self.eventFilter = TableEditorEventFilter()
        self.tview.installEventFilter(self.eventFilter)

    def connect_delete(self, connect=True):
        if connect:
            self.delete_btn.clicked.connect(self.delete_selection)
        else:
            try:
                self.delete_btn.clicked.disconnect()
            except:
                pass  # OK to fail when switching between R and T type xs

    def undo(self):
        self.tview.undoStack.undo()

    def redo(self):
        self.tview.undoStack.redo()

    def setup_tview(self):
        self.tview = TableView()
        self.tview_lout.addWidget(self.tview)

    def setSizeHint(self, width, height):
        self._sizehint = QSize(width, height)

    def sizeHint(self):
        if self._sizehint is not None:
            return self._sizehint
        return super(TableEditorWidget, self).sizeHint()

    def copy_selection(self):
        selection = self.tview.selectedIndexes()
        if selection:
            rows = sorted(index.row() for index in selection)
            columns = sorted(index.column() for index in selection)
            rowcount = rows[-1] - rows[0] + 1
            colcount = columns[-1] - columns[0] + 1
            table = [[""] * colcount for _ in range(rowcount)]
            for index in selection:
                row = index.row() - rows[0]
                column = index.column() - columns[0]
                table[row][column] = str(index.data())
            stream = io.StringIO()
            csv.writer(stream, delimiter="\t").writerows(table)
            QApplication.clipboard().setText(stream.getvalue())

    def paste(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        self.before_paste.emit()
        paste_str = QApplication.clipboard().text()
        rows = paste_str.split("\n")
        num_rows = len(rows) - 1
        num_cols = rows[0].count("\t") + 1
        sel_ranges = self.tview.selectionModel().selection()
        if len(sel_ranges) == 1:
            top_left_idx = sel_ranges[0].topLeft()
            sel_col = top_left_idx.column()
            sel_row = top_left_idx.row()
            if sel_col + num_cols > self.tview.model().columnCount():
                QApplication.restoreOverrideCursor()
                self.uc.bar_warn("Too many columns to paste.")
                self.uc.log_info("Too many columns to paste.")
                return
            if sel_row + num_rows > self.tview.model().rowCount():
                self.tview.model().insertRows(
                    self.tview.model().rowCount(),
                    num_rows - (self.tview.model().rowCount() - sel_row),
                )
                for i in range(self.tview.model().rowCount()):
                    self.tview.setRowHeight(i, 20)
            for row in range(num_rows):
                columns = rows[row].split("\t")
                for i, col in enumerate(columns):
                    if not is_number(col):
                        columns[i] = ""
                [
                    self.tview.model().setItem(sel_row + row, sel_col + col, StandardItem())
                    for col in range(len(columns))
                ]
                for col in range(len(columns)):
                    self.tview.model().item(sel_row + row, sel_col + col).setData(
                        columns[col].strip(), role=Qt.EditRole
                    )
            self.after_paste.emit()
            self.tview.model().dataChanged.emit(
                top_left_idx.parent(),
                self.tview.model().createIndex(sel_row + num_rows, sel_col + num_cols),
            )
        QApplication.restoreOverrideCursor()

    def delete_selection(self):
        indices = []
        for i in self.tview.selectionModel().selectedRows():
            index = QtCore.QPersistentModelIndex(i)
            indices.append(index)
        for i in indices:
            self.tview.model().removeRow(i.row())
        if indices:
            self.after_delete.emit()

class CommandItemEdit(QUndoCommand):
    """
    Command for undoing/redoing text edit changes, to be placed in undostack.
    """

    def __init__(self, widget, item, oldText, newText, description):
        QUndoCommand.__init__(self, description)
        self.item = item
        self.widget = widget
        self.oldText = oldText
        self.newText = newText

    def redo(self):
        self.item.model().itemDataChanged.disconnect(self.widget.itemDataChangedSlot)
        self.item.setText(self.newText)
        self.item.model().itemDataChanged.connect(self.widget.itemDataChangedSlot)

    def undo(self):
        self.item.model().itemDataChanged.disconnect(self.widget.itemDataChangedSlot)
        try:
            self.item.setText(self.oldText)
        except TypeError:
            self.item.setText("")
        self.item.model().itemDataChanged.connect(self.widget.itemDataChangedSlot)


#     def redo(self):
#         self.widget.connect_itemDataChanged(False)
#         self.item.setText(self.newText)
#         self.widget.connect_itemDataChanged(True)
#
#     def undo(self):
#         self.widget.connect_itemDataChanged(False)
#         try:
#             self.item.setText(self.oldText)
#         except TypeError:
#             self.item.setText("")
#         self.widget.connect_itemDataChanged(True)


class TableEditorEventFilter(QObject):
    def eventFilter(self, receiver, event):
        if event.type() == QEvent.KeyPress:
            if event.modifiers() & Qt.ControlModifier:
                if event.key() == Qt.Key_C:
                    table_editor_widget = receiver.parent()
                    if isinstance(table_editor_widget, TableEditorWidget):
                        table_editor_widget.copy_selection()
                    return True
                elif event.key() == Qt.Key_V:
                    table_editor_widget = receiver.parent()
                    if isinstance(table_editor_widget, TableEditorWidget):
                        table_editor_widget.paste()
                    return True
        return super(TableEditorEventFilter, self).eventFilter(receiver, event)

class StandardItemModel(QStandardItemModel):
    """
    Items will emit this signal when edited.
    """

    itemDataChanged = pyqtSignal(object, object, object, object)


class StandardItem(QStandardItem):
    """
    Subclass QStandardItem to reimplement setData to emit itemDataChanged.
    """

    def setData(self, newValue, role=Qt.UserRole + 1):
        if role == Qt.EditRole:
            oldValue = self.data(role)
            QStandardItem.setData(self, newValue, role)
            model = self.model()
            if model is not None and oldValue != newValue:
                model.itemDataChanged.emit(self, oldValue, newValue, role)
            return
        elif role == Qt.CheckStateRole:
            oldValue = self.data(role)
            QStandardItem.setData(self, newValue, role)
            model = self.model()
            if model is not None and oldValue != newValue:
                model.itemDataChanged.emit(self, oldValue, newValue, role)
            return
        else:
            QStandardItem.setData(self, newValue, role)


class TableView(QTableView):
    def __init__(self):
        QTableView.__init__(self)
        model = StandardItemModel()
        self.setModel(model)
        self.model().itemDataChanged.connect(self.itemDataChangedSlot)
        self.undoStack = QUndoStack(self)

    def setModel(self, model):
        if not isinstance(model, StandardItemModel):
            msg = "Model for TableView object must be StandardItem type"
            QgsMessageLog.logMessage(msg)
            return Exception(msg)
        super().setModel(model)
        self.undoStack = QUndoStack(self)
        self.connect_itemDataChanged(True)

    def connect_itemDataChanged(self, connect=True):
        if connect:
            self.model().itemDataChanged.connect(self.itemDataChangedSlot)
        else:
            self.model().itemDataChanged.disconnect()

    def itemDataChangedSlot(self, item, oldValue, newValue, role):
        """
        Slot used to push changes of existing items onto undoStack.
        """
        if role == Qt.EditRole:
            command = CommandItemEdit(
                self,
                item,
                oldValue,
                newValue,
                "Text changed from '{0}' to '{1}'".format(oldValue, newValue),
            )
            self.undoStack.push(command)
            return True
